﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BlocklyBeta.BO;
using BlocklyBeta.DAO;
using BlocklyBeta.Service;

namespace BlocklyNew.MasterPage
{
    public partial class Modify : System.Web.UI.Page
    {
        BlockBO oBlocksBO = new BlockBO();
        BlocksCTRL oBlocksCTRL = new BlocksCTRL();
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write(Session["value"].ToString());
            txtBolck.Text = Session["value"].ToString();
        }

        protected void btnReturn_Click(object sender, EventArgs e)
        {
            txtBolck.Text = "";
            Response.Redirect("Proyectos.aspx");
        }
    }
}